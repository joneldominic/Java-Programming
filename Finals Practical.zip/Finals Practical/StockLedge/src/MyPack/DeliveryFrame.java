/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPack;

import java.awt.Dimension;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Keen
 */
public class DeliveryFrame extends javax.swing.JFrame {
    
    ArrayList<Integer> supplierID = new ArrayList<Integer>();
    ArrayList<Integer> userID = new ArrayList<Integer>();
    
    /**
     * Creates new form DeliveryFrame
     */
    
    public DeliveryFrame() {
        initComponents();
        
        fillDeliveryTable("");
        fillSupplierCB();
        jComboBox_Supplier.setSelectedIndex(-1);
        fillUserCB();
        jComboBox_RecStaff.setSelectedIndex(-1);
    }
    
    private void fillSupplierCB(){   
         Connection myCon= myConnect.ConnectDB();
         String qry ="SELECT SupplierID, SupplierName  FROM supplier ORDER BY supplierID ASC";
         
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            ResultSet rs = myStat.executeQuery();
            
            jComboBox_Supplier.removeAllItems();
            supplierID.clear();
            while(rs.next()){
                supplierID.add(rs.getInt("SupplierID"));
                jComboBox_Supplier.addItem(rs.getString("SupplierName"));               
            }            
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }      
    }
    
    private int getSelectedSuppIDIndex(int supID){
        int index = -1;
               
        for(int i = 0; i<supplierID.size(); i++){
            if(supplierID.get(i) == supID){
                index = i;
                return index;
            }
        }
        return index;
    }
    
    private void fillUserCB(){   
         Connection myCon= myConnect.ConnectDB();
         String qry ="SELECT userID, Fname, Mname, Lname  FROM user ORDER BY userID ASC";
         
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            ResultSet rs = myStat.executeQuery();
            
            jComboBox_RecStaff.removeAllItems();
            userID.clear();
            while(rs.next()){
                userID.add(rs.getInt("userID"));
                jComboBox_RecStaff.addItem(rs.getString("Fname") + " " + rs.getString("Lname"));               
            }            
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }      
    }
    
    private int getSelectedUserIDIndex(int uID){
        int index = -1;
               
        for(int i = 0; i<userID.size(); i++){
            if(userID.get(i) == uID){
                index = i;
                return index;
            }
        }
        return index;
    }
    
    private void fillDeliveryTable(String suppName) {
        
        Connection myCon= myConnect.ConnectDB();
         
        String qry = "SELECT dr.DRNum as DRNum, s.SupplierName , dr.DateDel FROM deliveryreceipt AS dr INNER JOIN supplier AS s ON dr.SupplierID = s.SupplierID WHERE s.SupplierName LIKE ? ORDER BY DRNum ASC";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setString(1, suppName + "%");
            ResultSet rs = myStat.executeQuery();
            
            //Set table data
            DefaultTableModel model = (DefaultTableModel) jTable_DRecords.getModel();
            model.setRowCount(0);
            
            while(rs.next())
            { 
                model.insertRow(jTable_DRecords.getRowCount(), new Object[] {rs.getInt("DRNum"), rs.getString("s.SupplierName"), rs.getString("dr.DateDel")});
            }
            
        } catch (Exception e){
           JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void setCurrentDeliveryRec(int DrID, String suppName){
        Connection myCon= myConnect.ConnectDB();
         
        String qry = "SELECT DRID, DRNum, s.SupplierID, s.SupplierName, DateDel, TotalAmt, paidAmt, userid FROM deliveryreceipt"
                + " INNER JOIN supplier AS s ON deliveryreceipt.SupplierID = s.SupplierID "
                + "WHERE DRNUM = ? AND s.SupplierName = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setInt(1, DrID);
            myStat.setString(2, suppName);
            ResultSet rs = myStat.executeQuery();
            
            if(rs.next())
            { 
              jTextField_DRNo.setText(String.valueOf(rs.getInt("DRNum")));
              jTextField_DRID.setText(String.valueOf(rs.getInt("DRID")));
              jComboBox_Supplier.setSelectedIndex(getSelectedSuppIDIndex(rs.getInt("s.SupplierID")));
              jTextField_Date.setText(rs.getString("DateDel"));
              jTextField_AmountPaid.setText(String.valueOf(rs.getInt("paidAmt")));
              jTextField_TotalAmount.setText(String.valueOf(rs.getInt("TotalAmt")));
                  jComboBox_RecStaff.setSelectedIndex(getSelectedUserIDIndex(rs.getInt("userid")));
            }
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private int getMaxDRecID(){
        int maxID = -1;
        
        Connection myCon= myConnect.ConnectDB();
         
        String qry = "SELECT MAX(DRID) as maxID FROM deliveryreceipt";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            ResultSet rs = myStat.executeQuery();
            
            if(rs.next())
            { 
                maxID = rs.getInt("maxID");
            }
            
            return maxID;
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        return maxID;
    }
    
    private void AddItemCLick(int DrID){
        Connection myCon= myConnect.ConnectDB();
        String qry = "INSERT INTO `deliveryreceipt`(DRID, DRNUM, supplierID, datedel, totalamt, paidamt, userid) "
                + "VALUES (?, 0, 0, \"000/00/00\", 0, 0, 0) ";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setInt(1, DrID);
            myStat.executeUpdate();
            myCon.close();
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }
    
    }
            
    
    private void getNewlyAddedDRec(){
        Connection myCon= myConnect.ConnectDB();
         
        String qry = "SELECT DRID, DRNum, s.SupplierID, s.SupplierName, DateDel, TotalAmt, paidAmt, userid FROM deliveryreceipt"
                + " INNER JOIN supplier AS s ON deliveryreceipt.SupplierID = s.SupplierID "
                + "WHERE DRID = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setInt(1, getMaxDRecID());
            ResultSet rs = myStat.executeQuery();
            
            if(rs.next())
            { 
                jTextField_DRNo.setText(String.valueOf(rs.getInt("DRNum")));
                jTextField_DRID.setText(String.valueOf(rs.getInt("DRID")));
                jComboBox_Supplier.setSelectedIndex(getSelectedSuppIDIndex(rs.getInt("s.SupplierID")));
                jTextField_Date.setText(rs.getString("DateDel"));
                jTextField_AmountPaid.setText(String.valueOf(rs.getInt("paidAmt")));
                jTextField_TotalAmount.setText(String.valueOf(rs.getInt("TotalAmt")));
                jComboBox_RecStaff.setSelectedIndex(getSelectedUserIDIndex(rs.getInt("userid")));
            }
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void setTotalItemRec(int DrID, int supID){
        Connection myCon= myConnect.ConnectDB();
         
        String qry = "SELECT TotalAmt FROM deliveryreceipt"
                + " INNER JOIN supplier AS s ON deliveryreceipt.SupplierID = s.SupplierID "
                + "WHERE DRNUM = ? AND s.SupplierID = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setInt(1, DrID);
            myStat.setInt(2, DrID);
           
            ResultSet rs = myStat.executeQuery();
            
            if(rs.next())
            { 
                jTextField_TotalAmount.setText(String.valueOf(rs.getInt("TotalAmt")));
            }
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void clearCurrDeliveryFields()
    {
        jTextField_DRNo.setText("");
        jTextField_DRID.setText("");
        jTextField_Date.setText("");
        jComboBox_Supplier.setSelectedIndex(-1);
        jTextField_AmountPaid.setText("0");
        jTextField_TotalAmount.setText("0");
        jComboBox_RecStaff.setSelectedIndex(-1);
    }
    
    private void saveDelivery()
    {
        Connection myCon= myConnect.ConnectDB();
        String qry = "UPDATE `deliveryreceipt` SET `DRNum` = ?, `SupplierID` = ? , `DateDel` = ?, `TotalAmt` = ?, `paidAmt` = ?, `userid` = ? WHERE ? ";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setString(1, jTextField_DRNo.getText());
            myStat.setInt(2, supplierID.get(jComboBox_Supplier.getSelectedIndex()));
            myStat.setString(3, jTextField_Date.getText());
            myStat.setInt(4, Integer.valueOf(jTextField_TotalAmount.getText()));
            myStat.setInt(5, Integer.valueOf(jTextField_AmountPaid.getText()));
            myStat.setInt(6, userID.get(jComboBox_RecStaff.getSelectedIndex()));
             myStat.setInt(7, Integer.valueOf(jTextField_DRID.getText()));
           
            myStat.executeUpdate();
            myCon.close();
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }
    
    }
    
    private void getDeliveryItems(int DRID)
    {
        Connection myCon= myConnect.ConnectDB();
         
        String qry = "SELECT deliveryitems.StockID, stock2014.description, deliveryitems.BuyingPrice, "
                + "deliveryitems.Qty, deliveryitems.Amount FROM deliveryitems INNER JOIN "
                + "stock2014 ON deliveryitems.StockID  = stock2014.stockID WHERE DRID = ?";
        
        try {
            
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setInt(1, DRID);
            ResultSet rs = myStat.executeQuery();

            //Set table data
            DefaultTableModel model = (DefaultTableModel) jTable_DeliveryItems.getModel();
            model.setRowCount(0);

            while(rs.next())
            { 
                int stockCode = rs.getInt("deliveryitems.StockID");
                String desc = rs.getString("stock2014.description");
                int buyingP = rs.getInt("deliveryitems.BuyingPrice");
                int delQty = rs.getInt("deliveryitems.Qty");
                int delAmount = rs.getInt("deliveryitems.Amount");
                
                model.insertRow(jTable_DeliveryItems.getRowCount(), new Object[] {stockCode, desc, buyingP, delQty, delAmount});
            }
            
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_DRecords = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jButton_AddDelivery = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextField_DRNo = new javax.swing.JTextField();
        jTextField_DRID = new javax.swing.JTextField();
        jTextField_Date = new javax.swing.JTextField();
        jComboBox_Supplier = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable_DeliveryItems = new javax.swing.JTable();
        jButton_AddItem = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField_AmountPaid = new javax.swing.JTextField();
        jComboBox_RecStaff = new javax.swing.JComboBox<>();
        jTextField_TotalAmount = new javax.swing.JTextField();
        jButton_AddItem1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Delivery Form");
        setResizable(false);

        jPanel1.setBackground(java.awt.Color.decode("#dbffff"));

        jPanel2.setBackground(java.awt.Color.decode("#dbffff"));

        jTable_DRecords.setBackground(java.awt.Color.decode("#eaffff"));
        jTable_DRecords.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "DR No", "Supplier", "Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_DRecords.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable_DRecordsMouseReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jTable_DRecords);
        if (jTable_DRecords.getColumnModel().getColumnCount() > 0) {
            jTable_DRecords.getColumnModel().getColumn(0).setResizable(false);
            jTable_DRecords.getColumnModel().getColumn(0).setPreferredWidth(90);
            jTable_DRecords.getColumnModel().getColumn(1).setResizable(false);
            jTable_DRecords.getColumnModel().getColumn(1).setPreferredWidth(250);
            jTable_DRecords.getColumnModel().getColumn(2).setResizable(false);
            jTable_DRecords.getColumnModel().getColumn(2).setPreferredWidth(150);
        }

        jLabel1.setText("Delivery");

        jButton_AddDelivery.setText("Add Delivery");
        jButton_AddDelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_AddDeliveryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton_AddDelivery)
                .addGap(112, 112, 112))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 351, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton_AddDelivery)
                .addGap(17, 17, 17))
        );

        jPanel3.setBackground(java.awt.Color.decode("#dbffff"));

        jLabel2.setText("*DR No. :");

        jLabel3.setText("*Supplier :");

        jLabel4.setText("DR ID :");

        jLabel5.setText("Delivery Date :");

        jTextField_DRNo.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        jTextField_DRID.setEditable(false);
        jTextField_DRID.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        jTextField_Date.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        jTable_DeliveryItems.setBackground(java.awt.Color.decode("#eaffff"));
        jTable_DeliveryItems.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Stock Code", "Description", "Buying Price", "Qty", "Amount"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(jTable_DeliveryItems);
        if (jTable_DeliveryItems.getColumnModel().getColumnCount() > 0) {
            jTable_DeliveryItems.getColumnModel().getColumn(0).setResizable(false);
            jTable_DeliveryItems.getColumnModel().getColumn(0).setPreferredWidth(90);
            jTable_DeliveryItems.getColumnModel().getColumn(1).setResizable(false);
            jTable_DeliveryItems.getColumnModel().getColumn(1).setPreferredWidth(250);
            jTable_DeliveryItems.getColumnModel().getColumn(2).setResizable(false);
            jTable_DeliveryItems.getColumnModel().getColumn(2).setPreferredWidth(100);
            jTable_DeliveryItems.getColumnModel().getColumn(3).setResizable(false);
            jTable_DeliveryItems.getColumnModel().getColumn(4).setResizable(false);
        }

        jButton_AddItem.setText("Add Item");
        jButton_AddItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_AddItemActionPerformed(evt);
            }
        });

        jLabel6.setText("Amount Paid :");

        jLabel7.setText("*Receiving Staff :");

        jLabel8.setText("Total Amount :");

        jTextField_AmountPaid.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField_AmountPaid.setText("0");

        jTextField_TotalAmount.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField_TotalAmount.setText("0");

        jButton_AddItem1.setText("Cancel");
        jButton_AddItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_AddItem1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel6))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jTextField_AmountPaid, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField_TotalAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jComboBox_RecStaff, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField_DRNo, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox_Supplier, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField_DRID, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                            .addComponent(jTextField_Date))))
                .addGap(67, 67, 67))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(127, 127, 127)
                .addComponent(jButton_AddItem1)
                .addGap(62, 62, 62)
                .addComponent(jButton_AddItem)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(jTextField_DRNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField_DRID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(jTextField_Date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox_Supplier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton_AddItem)
                    .addComponent(jButton_AddItem1))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8)
                    .addComponent(jTextField_AmountPaid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField_TotalAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jComboBox_RecStaff, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_AddItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_AddItemActionPerformed
        if(jButton_AddDelivery.getText() == "Add Delivery" && !jTextField_DRID.getText().trim().isEmpty())
        {
            //Add Item process----------------------
            AddItem IFrame = new AddItem(Integer.valueOf(jTextField_DRID.getText()));  
            JDialog dialog = new JDialog(IFrame);
            dialog.setTitle(IFrame.getTitle());
            dialog.setSize(new Dimension(IFrame.getWidth(), IFrame.getHeight()));
            dialog.setLocationRelativeTo(IFrame);
            dialog.add(IFrame.getContentPane());
            dialog.setModal(true);
            dialog.setVisible(true);
            
            int supID = supplierID.get(jComboBox_Supplier.getSelectedIndex());
            setTotalItemRec(Integer.valueOf(jTextField_DRID.getText()), supID);
            getDeliveryItems(Integer.valueOf(jTextField_DRID.getText()));
        }       
        else if (jTextField_DRID.getText().trim().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Not Supplier Selected", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButton_AddItemActionPerformed

    private void jTable_DRecordsMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_DRecordsMouseReleased
        
        int sRow = jTable_DRecords.getSelectedRow();
        setCurrentDeliveryRec(Integer.valueOf(jTable_DRecords.getModel().getValueAt(sRow, 0).toString()), jTable_DRecords.getModel().getValueAt(sRow, 1).toString());
        getDeliveryItems(Integer.valueOf(jTextField_DRID.getText()));
    }//GEN-LAST:event_jTable_DRecordsMouseReleased

    private void jButton_AddDeliveryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_AddDeliveryActionPerformed
        
        if(jButton_AddDelivery.getText() == "Add Delivery")
        {
            //For Adding
            jButton_AddDelivery.setText("Save Delivery");
            clearCurrDeliveryFields();
            jTextField_DRID.setText(String.valueOf(1 + getMaxDRecID()));
            AddItemCLick(Integer.valueOf(jTextField_DRID.getText()));
            
            
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate localDate = LocalDate.now();
            jTextField_Date.setText(dtf.format(localDate));
            
        }
        else if(jButton_AddDelivery.getText() == "Save Delivery")
        {
            //For Saving the new Stock        
            if(!jTextField_DRNo.getText().trim().isEmpty() && jComboBox_Supplier.getSelectedIndex() >= 0 && jComboBox_RecStaff.getSelectedIndex() >= 0)// && !jTextField_TotalAmount.getText().equals("0"))
            {
                saveDelivery();
                fillDeliveryTable("");
                getNewlyAddedDRec();
                
                jButton_AddDelivery.setText("Add Delivery");
                JOptionPane.showMessageDialog(null, "New Delivery Added", "Saved!", JOptionPane.INFORMATION_MESSAGE);

            }
            else
            {
                JOptionPane.showMessageDialog(null, "Cannot leave Fields with *(asterisk) Empty", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            
        }
    }//GEN-LAST:event_jButton_AddDeliveryActionPerformed

    private void jButton_AddItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_AddItem1ActionPerformed
        if(jButton_AddDelivery.getText() == "Save Delivery")
        {
            int dialogButton = JOptionPane.YES_NO_OPTION;
            int dialogResult = JOptionPane.showConfirmDialog(this, "New Record will not be save. Are you sure to cancel process?", "Warning", dialogButton);
            if(dialogResult == 0) {
                jButton_AddDelivery.setText("Add Delivery");
                clearCurrDeliveryFields();
            }
        }
    }//GEN-LAST:event_jButton_AddItem1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DeliveryFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DeliveryFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DeliveryFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DeliveryFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DeliveryFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_AddDelivery;
    private javax.swing.JButton jButton_AddItem;
    private javax.swing.JButton jButton_AddItem1;
    private javax.swing.JComboBox<String> jComboBox_RecStaff;
    private javax.swing.JComboBox<String> jComboBox_Supplier;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable_DRecords;
    private javax.swing.JTable jTable_DeliveryItems;
    private javax.swing.JTextField jTextField_AmountPaid;
    private javax.swing.JTextField jTextField_DRID;
    private javax.swing.JTextField jTextField_DRNo;
    private javax.swing.JTextField jTextField_Date;
    private javax.swing.JTextField jTextField_TotalAmount;
    // End of variables declaration//GEN-END:variables
}
