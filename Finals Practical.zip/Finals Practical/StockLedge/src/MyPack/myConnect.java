/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPack;

import java.sql.*;

/**
 *
 * @author Keen
 */
public class myConnect {
    private static Connection conn = null;
    public static Connection ConnectDB(){
        try{
            String username="root";
            String password="";
            String database = "jdbc:mysql://localhost/coop_db";
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(database,username,password);
            return conn;
        }catch (Exception e){
            System.out.println("Error " + e);
            return null; 
        }
    }   
}
