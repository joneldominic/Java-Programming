/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package blackjack;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author room103
 */
public class PlayBJ extends javax.swing.JFrame {
    BufferedImage tblTop;
    BufferedImage deckOFcards;
    Deck deck;                 // A deck of cards to be used in the game.
    BlackjackHand handP;       // The cards that have been dealt to the player.
    BlackjackHand handB;       // The cards that have been dealt to the banker.
    String message;            // A message to reflect the state of the game.
    boolean gameInProgress=false;  // Set to true when a game begins 
    Font bigFont;              // Font that will be used to display the message.
    //Modification
    private int Player1 = 0;
    private int Banker = 0;
    private String Player_Name = "Jonel";
    private int ctr = 0;

    
    /**
     * Creates new form PlayBJ
     */
    
    public PlayBJ() {
        initComponents();
        doNewGame();
    }
    
    private void doNewGame() {
        loadTableTop();
        
        
        
        
        String[] header= {"Game","Winner"};
        Object[][] body = new Object[0][2];
        tblGame.setModel(new DefaultTableModel(body, header));
        
        
        if (gameInProgress) {
         // Not allowed to start a new game if the current game is not over yet 
            message = "You still have to finish this game!";
            viewCards();
            return;
         }
            
         deck = new Deck();   // Create the deck and hand to use for this game.
	 handP = new BlackjackHand();
	 handB = new BlackjackHand();
	 deck.shuffle();
         for (int i=0; i<2; i++) {
	  	handP.addCard( deck.dealCard() ); // Deal a card into the hand of the Player.
	    	handB.addCard( deck.dealCard() ); // Deal a card into the hand of the Banker.
         }
        message = "Get More card or Evaluate?";
        gameInProgress = true;
        viewCards();
    } // end doNewGame()
    
    public void drawCard(Graphics g, Card card, int x, int y) {
        int cx;    // x-coord of upper left corner of the card inside cardsImage
        int cy;    // y-coord of upper left corner of the card inside cardsImage
        if (card == null) {
            cy = 4*123;   // coords for a face-down card.
            cx = 2*79;
        }
        else {
            cx = (card.getValue()-1)*79;
            System.out.println("(Suit, Value) = (" + card.getSuit() + ", " + card.getValue() + ")");
            switch (card.getSuit()) {
            case Card.CLUBS:    
               cy = 0; 
               break;
            case Card.DIAMONDS: 
               cy = 123; 
               break;
            case Card.HEARTS:   
               cy = 2*123; 
               break;
            default:  // spades   
               cy = 3*123; 
               break;
            }
         }
        getCardImage(x,y, cx, cy);
      } //end drawCard()
    
    private void getCardImage(int x, int y, int cx, int cy) {
        int dy=y;
        for (int c=cy; c < (cy+123); c++) {
            int dx = x;
            for (int r=cx; r < (cx+79); r++) {
                Color rgb = new Color(deckOFcards.getRGB(r, c));
                tblTop.setRGB(dx,dy, rgb.getRGB());
                ++dx;
            }
            ++dy;
        }        
    } //end getCardImage()
    
    private void viewCards() {
        lblStatus.setText(message);
        int ymid = tblTop.getHeight()/2;
        int wide = tblTop.getWidth();
        Graphics g = tblTop.createGraphics();
        int cardCt = handB.getCardCount()-1;
        System.out.println("view cards! Card Count " + cardCt );
        
        for (int i = 0; i < cardCt; i++) {
            drawCard(g, handB.getCard(i), 15 + i * (15+79), 15);
        }
        
        Card lcard = (gameInProgress) ? null : handB.getCard(cardCt);
        drawCard(g, lcard, 15 + cardCt * (15+79), 15);
        g.setColor(Color.LIGHT_GRAY);
        g.drawLine(3, ymid, wide-3, ymid);
        g.drawLine(3, ymid+1, wide-3, ymid+1);
        cardCt = handP.getCardCount();
        for (int i = 0; i < cardCt; i++) {
            drawCard(g, handP.getCard(i), 15 + i * (15+79), ymid + 30);
        }
        lblTableTop.repaint();
        g.dispose();
    } //end viewCards()

    private void loadTableTop() {
            try  {
                //reads File as image which is located at E:/BlackJack/src/ (only for my setup)
                deckOFcards = ImageIO.read(new File("F:/BlackJack/src/cards.png"));
                tblTop = ImageIO.read(new File("F:/BlackJack/src/stripe-table-cloth.jpg"));                
            } catch (IOException e) {
                System.out.println("Invalid image file");
                System.exit(0);  
            }        
       ImageIcon icon = new ImageIcon(tblTop);
       lblTableTop.setIcon(icon);             
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // initcomponent is build dynamically                          

    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblTableTop = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblGame = new javax.swing.JTable();
        btnEvaluate = new javax.swing.JButton();
        btnDrawMore = new javax.swing.JButton();
        lblStatus = new javax.swing.JLabel();
        shuffleOrContinueGame = new javax.swing.JButton();
        JOptionPane = new javax.swing.JOptionPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        mnuNewGame = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Black Jack (JDT)");
        setResizable(false);

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTableTop, javax.swing.GroupLayout.DEFAULT_SIZE, 564, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTableTop, javax.swing.GroupLayout.DEFAULT_SIZE, 342, Short.MAX_VALUE)
                .addContainerGap())
        );

        tblGame.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Game", "Winner"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblGame.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(tblGame);
        if (tblGame.getColumnModel().getColumnCount() > 0) {
            tblGame.getColumnModel().getColumn(0).setResizable(false);
            tblGame.getColumnModel().getColumn(0).setHeaderValue("Game");
            tblGame.getColumnModel().getColumn(1).setResizable(false);
            tblGame.getColumnModel().getColumn(1).setHeaderValue("Winner");
        }

        btnEvaluate.setText("Evaluate");
        btnEvaluate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEvaluateActionPerformed(evt);
            }
        });

        btnDrawMore.setText("Draw Another Card");
        btnDrawMore.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDrawMoreActionPerformed(evt);
            }
        });

        lblStatus.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        lblStatus.setText("Get More Card or Evaluate?");

        shuffleOrContinueGame.setText("Shuffle Cards / Continue to Next Round");
        shuffleOrContinueGame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shuffleOrContinueGameActionPerformed(evt);
            }
        });

        JOptionPane.setEnabled(false);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(91, 91, 91)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnDrawMore, javax.swing.GroupLayout.DEFAULT_SIZE, 148, Short.MAX_VALUE)
                            .addComponent(btnEvaluate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(JOptionPane, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 260, Short.MAX_VALUE)
                            .addComponent(shuffleOrContinueGame, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 572, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(JOptionPane, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(btnDrawMore)
                        .addGap(19, 19, 19)
                        .addComponent(btnEvaluate)
                        .addGap(18, 18, 18)
                        .addComponent(shuffleOrContinueGame, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        jMenu1.setText("Game");

        mnuNewGame.setText("New Game");
        mnuNewGame.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuNewGameActionPerformed(evt);
            }
        });
        jMenu1.add(mnuNewGame);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnuNewGameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuNewGameActionPerformed
        
        Player1 = 0;
        Banker = 0;
        ctr = 0;
        
        DefaultTableModel model = (DefaultTableModel) tblGame.getModel();
        
        while(model.getRowCount()>0){
            for (int i=0 ; i < model.getRowCount() ; i++){
                  model.removeRow(i);
                }
         }
        doNewGame();  
    }//GEN-LAST:event_mnuNewGameActionPerformed

    private void btnDrawMoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDrawMoreActionPerformed
        
        DefaultTableModel model = (DefaultTableModel) tblGame.getModel();
        
        if (gameInProgress == false) {
            message = "Click \"Continue Next Round\" to proceed to the next round or \"New Game\" to start a new game!";
            viewCards();
            return;
        }
        
        int cardCt = handP.getCardCount();
        System.out.println("Player cards " + cardCt);
        if (cardCt < 5) {
            handP.addCard( deck.dealCard() );     // Deal a card to the hand.
        } else {
            message = "You exceeded the number of cards already";
        }
        int cvalue = handP.getBlackjackValue();
        System.out.println("Cards value " + cvalue);
        if (cvalue > 21) {
            gameInProgress = false;
            message = "Too bad! You lose.";
            ctr++;
            Banker++;
            model.addRow(new Object[]{ctr,"Banker"});
            gameInProgress = false;
            message = "Ops! You LOSE this round. \n Banker's cards' value is bigger than yours. ";
        }
        viewCards();
    }//GEN-LAST:event_btnDrawMoreActionPerformed

    private void btnEvaluateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEvaluateActionPerformed
        
        DefaultTableModel model = (DefaultTableModel) tblGame.getModel();
        
        if (gameInProgress == false) {
            // If the game has ended, it was an error to click "Lower",
            // So set up an error message and abort processing.
            message = "Click \"Continue Next Round\" to proceed to the next round or  \"New Game\" to start a new game!";
            viewCards();
            return;
        }else {
                int bvalue = handB.getBlackjackValue();
            	while ((bvalue < 15) && (handB.getCardCount() < 5) ) {
                    handB.addCard( deck.dealCard() );
                    bvalue = handB.getBlackjackValue();
                }
                
                int pvalue = handP.getBlackjackValue();
                String score = "Calculation: Your score is " + pvalue + " and the banker is " + bvalue + ".";
                if (bvalue < 22) {
                    ctr++;
                    if (pvalue > bvalue) {
                        Player1++;
                        model.addRow(new Object[]{ctr,Player_Name});
                        gameInProgress = false;
                        message = "Wow! You WIN this round! \n" + score;			
                    }
                    else if(pvalue == bvalue){
                        model.addRow(new Object[]{ctr,"None (Draw)"});
                        gameInProgress = false;
                        message = "As to this round, it is a draw. \n" + score;
                    }
                    
                    else {
                        Banker++;
                        model.addRow(new Object[]{ctr,"Banker"});    
                        gameInProgress = false;
                        message = "Ops! You LOSE this round \n" + score;
                    }
                }
                viewCards();
        }
    }//GEN-LAST:event_btnEvaluateActionPerformed

    private void shuffleOrContinueGameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shuffleOrContinueGameActionPerformed
        if (ctr>=10){
            JOptionPane.showMessageDialog(null,"Game Over!");
            if (Player1>Banker){
                JOptionPane.showMessageDialog(null,"Congratulations " + Player_Name +  ". You got the most Wins");
            }
            else if(Player1<Banker){
                JOptionPane.showMessageDialog(null,"Ops! Better luck next time " + Player_Name + ". You got the most Losses");
            }
            else {
                JOptionPane.showMessageDialog(null,"It’s a Draw!");
            }
            message = "Game is Over. Click\"New Game\" to start a new game!";
            lblStatus.setText(message);
        } 
        else {
            loadTableTop();
            deck = new Deck();   // Create the deck and hand to use for this game.
            handP = new BlackjackHand();
            handB = new BlackjackHand();
             deck.shuffle();
            for (int i=0; i<2; i++) {
                    handP.addCard( deck.dealCard() ); // Deal a card into the hand of the Player.
                    handB.addCard( deck.dealCard() ); // Deal a card into the hand of the Banker.
                 }
        message = "Get More card or Evaluate?";
        gameInProgress = true;
        viewCards();
        }               
    }//GEN-LAST:event_shuffleOrContinueGameActionPerformed

    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PlayBJ.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PlayBJ.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PlayBJ.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PlayBJ.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new PlayBJ().setVisible(true);
            }
        });
    }               

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JOptionPane JOptionPane;
    private javax.swing.JButton btnDrawMore;
    private javax.swing.JButton btnEvaluate;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblTableTop;
    private javax.swing.JMenuItem mnuNewGame;
    private javax.swing.JButton shuffleOrContinueGame;
    private javax.swing.JTable tblGame;
    // End of variables declaration//GEN-END:variables
}
