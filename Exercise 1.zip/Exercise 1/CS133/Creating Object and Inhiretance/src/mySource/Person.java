/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mySource;

/**
 *
 * @author Keen
 */
public class Person {
    
    String firstName;
    String middleName;
    String Surname;
    
    public Person (String fName, String midName, String sName){
        
        firstName = fName;
        middleName = midName;
        Surname = sName;
    
    }
    
    public String getName(){
            
            return (Surname + ", " + firstName + " " + middleName);
            
    }
    
}
