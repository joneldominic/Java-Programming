/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mySource;

/**
 *
 * @author Keen
 */
public class Parent {
         
    Person Mama;
    Person Papa;
    Sibling Child;
     
    Parent (Person Father, Person Mother){
         
        Mama = Mother;
        Papa = Father;
       
     }
     
     public String getMother(){
         
         return Mama.getName();
     }
     
     public String getFather(){
         
         return Papa.getName();
     }
}
