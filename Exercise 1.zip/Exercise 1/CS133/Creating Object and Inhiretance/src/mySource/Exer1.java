/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mySource;

/**
 *
 * @author Keen
 */
public class Exer1 {
    
    private static void viewFamily(Parent parent) {
        
        System.out.println("Father :" + parent.getFather());
        System.out.println("Mother :" + parent.getMother());
        Sibling tmp = parent.Child;
        int ctr=0;
        while (tmp != null) {
            System.out.println((++ctr) + ".) " + tmp.getName());
            tmp = tmp.getSibling();
            }
        }

    public static void main(String[] args) {
        
        /*
        Person f = new Person("Winston","Membrebe","Tabada");
        Person m = new Person("Maria Aurora Teresita", "Warque", "Tabada");
        Parent tabadawarque = new Parent(f, m);
        tabadawarque.Child = new Sibling("Abraham Winston", "Warque", "Tabada");
        Sibling anak = tabadawarque.Child; 
        anak.setSibling(new Person("Paul Winston","Warque","Tabada"));
        anak = anak.getSibling();
        anak.setSibling(new Person("Sarah Aurora","Warque","Tabada"));
        anak = anak.getSibling();
        anak.setSibling(new Person("David Winston","Warque","Tabada"));
        anak = anak.getSibling();
        anak.setSibling(new Person("John Winston","Warque","Tabada"));
        anak = anak.getSibling();
        anak.setSibling(new Person("Ignatius Winston","Warque","Tabada"));
        viewFamily(tabadawarque);
        */
        
        Person father = new Person("Dionilo", "Loro", "Tapang");
        Person mother = new Person("Zosima", "Esclamado", "Tapang");
        Parent BraveFamily = new Parent(father, mother);
        BraveFamily.Child = new Sibling ("Jonel Dominic", "Esclamado", "Tapang");
        Sibling igsoon = BraveFamily.Child;
        igsoon.setSibling(new Person("Zoe Dorothy", "Esclamado", "Tapang"));
        viewFamily(BraveFamily);
        
        }
}
