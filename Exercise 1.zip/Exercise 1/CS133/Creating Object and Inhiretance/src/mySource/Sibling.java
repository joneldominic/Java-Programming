/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mySource;

/**
 *
 * @author Keen
 */
public class Sibling extends Person{
    
    Sibling sibling;
   
    public Sibling(String sFName, String sMidName, String sSName){
        
        super(sFName, sMidName, sSName);
                
    }
    
    public void setSibling(Person Sibs){
        
        this.sibling = new Sibling(Sibs.firstName, Sibs.middleName, Sibs.Surname);
               
    }
    
    public Sibling getSibling(){
       
        return sibling;
    }
    
}
