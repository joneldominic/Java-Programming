/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPackage;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Keen
 */
public class Matrix {
    
    private int numRows;
    private int numCols;
    private double[][] data;
    
    public Matrix(double[][] arrData) {
        numRows = arrData.length;
        numCols = arrData[0].length;
        data = new double[numRows][numCols];
        
        for (int r=0; r < numRows; r++) {
            for (int c=0; c < numCols; c++) {
                data[r][c]= arrData[r][c];
            }
        }
    }
    
    public Matrix(int numRows, int numCols) {
        this.numRows = numRows;
        this.numCols = numCols;
        data = new double[numRows][numCols];
        
        for (int r=0; r < numRows; r++) {
            for (int c=0; c < numCols; c++) {
                data[r][c] = 0.0;
            }
        }
    }
    
    public int getRows() {
        return numRows;
    }
    
    public int getColumns() {
        return numCols;
    }
   
    public int size() {
        if (isSquare())
                return numRows;
        return -1;
    }
    
    public boolean isSquare() {
        return numRows == numCols;
    }
    
    public double getCell(int row, int col) throws MatrixException {
        if ((row>numRows) || (row<1)) {
            throw new MatrixException("Row index out of bounds!");
        }
        
        if ((col>numCols) || (col<1)) {
            throw new MatrixException("Column index out of bounds!");
        }
        return data[row-1][col-1];
    }
    
    public void setCell(int row, int col, double value) throws MatrixException {
        if ((row>numRows) || (row<1)) {
            throw new MatrixException("Row index out of bound!");
        }
        
        if ((col>numCols) || (col<1)) {
            throw new MatrixException("Column index out of bound!");
        }
        data[row-1][col-1] = value;
    }
    
    public Matrix transpose() {
        Matrix T = new Matrix(numCols, numRows);
        
        for (int r=1; r <= numCols; r++) {
            
            for (int c=1; c <= numRows; c++) {
                try {
                    T.setCell(r, c, data[c-1][r-1]);
                } catch (MatrixException msg) {
                    System.out.println("Error :" + msg.Error);
                }
            }
        }
        return T;
    }
    
    public Matrix times(Matrix B) throws MatrixException {
        if (numCols != B.getRows()) {
            throw new MatrixException("Matrix A columns not equal to Matrix B rows!");
        }
        
        Matrix C = new Matrix(numRows, B.getColumns());
       
        for (int r=1; r <= numRows; r++) {
            for(int c=1; c <= B.getColumns(); c++){
                double sumOfProd = 0;
                for(int j = 1; j<= B.getRows(); j++){
                     sumOfProd += (data[r -1][j-1] * B.getCell(j, c) );
                }
                C.setCell(r, c, sumOfProd);
            }
        }
        
        return C;
    }
    
    
    public Matrix add(Matrix B) throws MatrixException {
         
        if (numCols != B.getColumns()) {
            throw new MatrixException("Matrix A columns not equal to Matrix B columns!");
        }
        if (numRows != B.getRows()) {
            throw new MatrixException("Matrix A rows not equal to Matrix B rows!");            
        }      
        Matrix C = new Matrix(numRows, numCols);
        
        for (int r=1; r <= numRows; r++) {
            for (int c=1; c <= numCols; c++) {
                C.setCell(r, c, (data[r-1][c-1] + B.getCell(r, c)));
            }
        }

        return C;
    }
    
    public Matrix minus(Matrix B) throws MatrixException {
         
        if (numCols != B.getColumns()) {
            throw new MatrixException("Matrix A columns not equal to Matrix B columns!");
        }
        if (numRows != B.getRows()) {
            throw new MatrixException("Matrix A rows not equal to Matrix B rows!");            
        }      
        Matrix C = new Matrix(numRows, numCols);
        
        for (int r=1; r <= numRows; r++) {
            for (int c=1; c <= numCols; c++) {
                C.setCell(r, c, (data[r-1][c-1] - B.getCell(r, c)));
            }
        }

        return C;
    }
    
    public Matrix inverse(Matrix outMatrix) throws MatrixException {
        
        if(outMatrix.determinant(outMatrix) !=0){
            Matrix cofac = cofactor(outMatrix);
            Matrix inverse = cofac.multiplyByConstant(1.0/determinant(outMatrix));

            outMatrix = inverse.transpose();
        }
        else{
            throw new MatrixException("Matrix is Non-invertible/Singular");
           
        }
        
        return outMatrix;
    }
    
    public double determinant(Matrix matrix) throws MatrixException {
        if (!matrix.isSquare())
                throw new MatrixException("Matrix need to be square.");
        if (matrix.size() == 1){
                return matrix.getCell(0+1, 0+1);
        }

        if (matrix.size()==2) {
                return (matrix.getCell(0+1, 0+1) * matrix.getCell(1+1, 1+1)) - ( matrix.getCell(0+1, 1+1) * matrix.getCell(1+1, 0+1));
        }
        
        double sum = 0.0;
        for (int i=0; i<matrix.getColumns(); i++) {
                sum += changeSign(i) * matrix.getCell(0+1, i+1) * determinant(createSubMatrix(matrix, 0, i));
        }
        return sum;
    }
    
    private static int changeSign(int i) {
        if (i%2==0)
                return 1;
        return -1;
    }
    
    public static Matrix createSubMatrix(Matrix matrix, int excluding_row, int excluding_col) {
        Matrix mat = new Matrix(matrix.getRows()-1, matrix.getColumns()-1);
        int r = -1;
        for (int i=0;i<matrix.getRows();i++) {
                if (i==excluding_row){
                    continue;
                }
                
                r++;
                int c = -1;
                
                for (int j=0;j<matrix.getColumns();j++) {
                    if (j==excluding_col){
                        continue;
                    }   
                    try {
                        c++;
                        mat.setCell(r+1, c+1, matrix.getCell(i+1, j+1));
                    } 
                    catch (MatrixException err) {
                        Logger.getLogger(Matrix.class.getName()).log(Level.SEVERE, null, err);
                        System.out.println("Error : " + err.Error);
                    }
                }
        }
        return mat;
    }
    
    public Matrix cofactor(Matrix matrix) throws MatrixException {
        Matrix mat = new Matrix(matrix.getRows(), matrix.getColumns());
        for (int r=0; r < matrix.getRows(); r++) {
                for (int c=0; c < matrix.getColumns(); c++) {
                        mat.setCell(r+1, c+1, changeSign(r) * changeSign(c) * determinant(createSubMatrix(matrix, r, c)));
                }
        }
        
        return mat;
    }
    
    public Matrix multiplyByConstant(double constant) {
		Matrix mat = new Matrix(numRows, numCols);
		for (int i = 0; i < numRows; i++) {
			for (int j = 0; j < numCols; j++) {
                            
                            try {
                                mat.setCell(i+1, j+1, data[i][j] * constant);
                            } 
                            catch (MatrixException ex) {
                                Logger.getLogger(Matrix.class.getName()).log(Level.SEVERE, null, ex);
                            }
			}
		}
		return mat;
	}
        
    public String toString() {
        NumberFormat formatter = new DecimalFormat("#0.000");     
        String str="";
        for (int r=0; r < numRows; r++) {
            for (int c=0; c < numCols; c++) {
                str += " " + formatter.format(data[r][c]);
            }
            str += "\n";
        }
        return str;
    }
    
}
