/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MyPackage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Keen
 */
public class MainForm extends javax.swing.JFrame {

    /**
     * Creates new form MainForm
     */
    ArrayList officeData = new ArrayList();
    
    public MainForm() {
        initComponents();
        fillTable("");
        getOfficeData();
    }
    
    private void fillTable(String val) {
        Connection myCon= myConnect.ConnectDB();
        String qry ="SELECT `memberID`, `Lname` , `Fname`, "
                + "`AmountPaid`  FROM `member` "
                + "WHERE `Lname` LIKE ? OR `Fname` LIKE ? Order by Lname ASC";
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry); 
            myStat.setString(1, val + "%" );
            myStat.setString(2, val + "%" );
            ResultSet rs = myStat.executeQuery();
            memberTable.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void fillDataFields(int selectedRow){
        
        Connection myCon= myConnect.ConnectDB();
        String qry ="SELECT `memberID`, `Lname` , `Mname`, `Fname`, `DateofBirth`, `PlaceofBirth`, `Salary`, `SourceofIncome`, `NearestRelative`, `Relationship`, `Status`,"
                + "`OfficeID` ,`Dependent`,`CurrentAddress`, `Occupation`,`Sex`, `StockShare`, `StockPaid`, `StockAmount`, `AmountPaid`  FROM `member` "
                + "WHERE `Lname` LIKE ? AND `Fname` LIKE ?";
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry); 
            myStat.setString(1, String.valueOf(memberTable.getValueAt(selectedRow, 1) +"%"));
            myStat.setString(2, String.valueOf(memberTable.getValueAt(selectedRow, 2)+"%"));
            
            ResultSet rs = myStat.executeQuery();
            
            if(rs.first()){
                idField.setText(rs.getString("memberID"));
                fNameField.setText(rs.getString("Fname"));
                mNameField.setText(rs.getString("Mname"));
                lNameField.setText(rs.getString("Lname"));
                bDayField.setText(rs.getString("DateofBirth"));
                bPlaceField.setText(rs.getString("PlaceofBirth"));
                sexField.setText(rs.getString("Sex"));
                homeAddField.setText(rs.getString("CurrentAddress"));
                occupationField.setText(rs.getString("Occupation"));
                salaryField.setText(rs.getString("Salary"));
                incomeField.setText(rs.getString("SourceofIncome"));
                relativeField.setText(rs.getString("NearestRelative"));
                relationField.setText(rs.getString("Relationship"));
                dependentsField.setText(rs.getString("Dependent"));
                stockShareField.setText(rs.getString("StockShare"));
                stockAmountField.setText(rs.getString("StockAmount"));
                stockPaidField.setText(rs.getString("StockPaid"));
                amountPaidField.setText(rs.getString("AmountPaid")); 
                officeField.setSelectedIndex(rs.getInt("OfficeID"));
                civilStatusCBox.setSelectedIndex(rs.getInt("Status"));
                
            }
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
        
    }

    private void getOfficeData(){
        
        Connection myCon= myConnect.ConnectDB();
        String qry ="SELECT `officeID`, `officeName` FROM `office` "
                + "Order by officeID ASC";
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            ResultSet rs = myStat.executeQuery();
            
            
            while(rs.next()){
                officeData.add(rs.getString("officeName"));
                officeField.addItem(rs.getString("officeName"));
            }
            
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }        
    }
    
    private void saveOrUpdateData(int selectedRow){
        
        Connection myCon= myConnect.ConnectDB();
        String qry = " UPDATE `member` SET `memberID` = ? , `Lname` =  ?, `Mname` = ?, `Fname` = ?, `DateofBirth` = ?, `PlaceofBirth` = ?, "
                + "`Sex` = ?, `CurrentAddress` = ? , `Occupation` = ? , `Status` = ? , `OfficeID` = ? , `Salary` = ? , `SourceofIncome` = ?,"
                + "`NearestRelative` = ? , `Relationship` = ? , `Dependent` = ? , `StockShare` = ? , `StockPaid` = ? , `StockAmount` = ? , `AmountPaid`  = ?"
                + " WHERE `memberID` = ? AND `Lname` = ? AND `Fname` = ?  ";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            
            myStat.setInt(1, Integer.valueOf(idField.getText()));
            myStat.setString(2, String.valueOf(lNameField.getText()));
            myStat.setString(3, String.valueOf(mNameField.getText()));
            myStat.setString(4, String.valueOf(fNameField.getText()));
            myStat.setString(5, String.valueOf(bDayField.getText()));
            myStat.setString(6, String.valueOf(bPlaceField.getText()));
            myStat.setString(7, String.valueOf(sexField.getText()));
            myStat.setString(8, String.valueOf(homeAddField.getText()));
            myStat.setString(9, String.valueOf(occupationField.getText()));
            myStat.setInt(10, civilStatusCBox.getSelectedIndex());
            myStat.setInt(11, officeField.getSelectedIndex());
            myStat.setString(12, String.valueOf(salaryField.getText()));
            myStat.setString(13, String.valueOf(incomeField.getText()));
            myStat.setString(14, String.valueOf(relativeField.getText()));
            myStat.setString(15, String.valueOf(relationField.getText()));
            myStat.setString(16, String.valueOf(dependentsField.getText()));
            myStat.setString(17, String.valueOf(stockShareField.getText()));
            myStat.setString(18, String.valueOf(stockPaidField.getText()));
            myStat.setString(19, String.valueOf(stockAmountField.getText()));
            myStat.setString(20, String.valueOf(amountPaidField.getText()));
            //For Where Clause
            myStat.setString(21, String.valueOf(memberTable.getValueAt(selectedRow, 0))); 
            myStat.setString(22, String.valueOf(memberTable.getValueAt(selectedRow, 1)));                  
            myStat.setString(23, String.valueOf(memberTable.getValueAt(selectedRow, 2))); 
            
            myStat.executeUpdate();
            myCon.close();
            
            fillTable("");
            clearFields();
            searchField.setText("");

            JOptionPane.showMessageDialog (null, "Record Succesfully Saved/Updated", "Success!", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("Success : " + "Save Succcesful");            
            
        } catch (Exception e){
            JOptionPane.showMessageDialog (null, "Saving Data Failure!", "Error", JOptionPane.ERROR_MESSAGE);
            JOptionPane.showMessageDialog (null, "Select Record to be Updated", "Error", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("Error: " + e);
        }
    }
    
    private void addRecord(){
        // Clears the search field
        searchField.setText("");
        
        Connection myCon= myConnect.ConnectDB();        
        
        String qry = "INSERT INTO `member` ( memberID, Lname, Mname, Fname, DateofBirth, PlaceofBirth, Sex, CurrentAddress, Occupation, Status, OfficeID, "
                + "Salary, SourceofIncome, NearestRelative, Relationship, Dependent, StockShare, StockPaid, StockAmount, AmountPaid )"
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            
            myStat.setInt(1, Integer.valueOf(idField.getText()));
            myStat.setString(2, String.valueOf(lNameField.getText()));
            myStat.setString(3, String.valueOf(mNameField.getText()));
            myStat.setString(4, String.valueOf(fNameField.getText()));
             myStat.setString(5, String.valueOf(bDayField.getText()));
            myStat.setString(6, String.valueOf(bPlaceField.getText()));
            myStat.setString(7, String.valueOf(sexField.getText()));
            myStat.setString(8, String.valueOf(homeAddField.getText()));
            myStat.setString(9, String.valueOf(occupationField.getText()));
            myStat.setInt(10, civilStatusCBox.getSelectedIndex());
            myStat.setInt(11, officeField.getSelectedIndex());
            myStat.setString(12, String.valueOf(salaryField.getText()));
            myStat.setString(13, String.valueOf(incomeField.getText()));
            myStat.setString(14, String.valueOf(relativeField.getText()));
            myStat.setString(15, String.valueOf(relationField.getText()));
            myStat.setString(16, String.valueOf(dependentsField.getText()));
            myStat.setString(17, String.valueOf(stockShareField.getText()));
            myStat.setString(18, String.valueOf(stockPaidField.getText()));
            myStat.setString(19, String.valueOf(stockAmountField.getText()));
            myStat.setString(20, String.valueOf(amountPaidField.getText()));
        
            myStat.executeUpdate();
            myCon.close();
            
            fillTable("");
            clearFields();
            searchField.setText("");
            
            JOptionPane.showMessageDialog (null, "Record Succesfully Added", "Success!", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("Success : " + "Saving Succcesful");
            
        } catch (Exception e){
            JOptionPane.showMessageDialog (null, "Saving Data Failure!", "Error", JOptionPane.ERROR_MESSAGE);
            JOptionPane.showMessageDialog(null, "Error: Cannot leave Fields Empty / Member ID already Exist", "Error", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("Error : " + e);
        }
    }
    
    private void deleteRecord(int selectedRow){
        
        Connection myCon= myConnect.ConnectDB();  
        String qry = "DELETE FROM `member` WHERE `memberID` = ? AND `Lname` = ? AND `Fname` = ? ";
         
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
          
            myStat.setString(1, String.valueOf(memberTable.getValueAt(selectedRow, 0))); 
            myStat.setString(2, String.valueOf(memberTable.getValueAt(selectedRow, 1)));                  
            myStat.setString(3, String.valueOf(memberTable.getValueAt(selectedRow, 2))); 
          
            myStat.executeUpdate();
            myCon.close();
            
            fillTable("");
            clearFields();
            searchField.setText("");

            JOptionPane.showMessageDialog (null, "Record Succesfully Deleted", "Success!", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("Success : " + "Record Succesfully Deleted");   
          
        } catch (Exception e){
            JOptionPane.showMessageDialog (null, "Deletion Failed!", "Error", JOptionPane.ERROR_MESSAGE);
            JOptionPane.showMessageDialog (null, "Select Record to be Deleted", "Error", JOptionPane.INFORMATION_MESSAGE);
            System.out.println("Error : " + e);
        }
        
    }
    
    private void clearFields(){
        
            idField.setText("");
            lNameField.setText("");
            mNameField.setText("");
            fNameField.setText("");
            bDayField.setText("");
            bPlaceField.setText("");
            sexField.setText("");
            homeAddField.setText("");
            occupationField.setText("");
            civilStatusCBox.setSelectedIndex(0);
            officeField.setSelectedIndex(0);
            salaryField.setText("");
            incomeField.setText("");
            relativeField.setText("");
            relationField.setText("");
            dependentsField.setText("");
            stockShareField.setText("");
            stockPaidField.setText("");
            stockAmountField.setText("");
            amountPaidField.setText("");
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        memberTable = new javax.swing.JTable();
        searchField = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        fNameField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        mNameField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        lNameField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        idField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        bDayField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        bPlaceField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        civilStatusCBox = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        homeAddField = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        occupationField = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        officeField = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        salaryField = new javax.swing.JTextField();
        incomeField = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        relativeField = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        dependentsField = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        stockShareField = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        stockAmountField = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        amountPaidField = new javax.swing.JTextField();
        stockPaidField = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        btnSaveAndUpdate = new javax.swing.JButton();
        btnAddMember = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        sexField = new javax.swing.JTextField();
        relationField = new javax.swing.JTextField();
        jOptionPane1 = new javax.swing.JOptionPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Coop Member Management (JDT)");

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        memberTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        )
    );
    memberTable.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            memberTableMouseClicked(evt);
        }
    });
    jScrollPane1.setViewportView(memberTable);

    searchField.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyPressed(java.awt.event.KeyEvent evt) {
            searchFieldKeyPressed(evt);
        }
        public void keyReleased(java.awt.event.KeyEvent evt) {
            searchFieldKeyReleased(evt);
        }
    });

    javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
    jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(
        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel1Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 209, Short.MAX_VALUE)))
            .addContainerGap())
    );
    jPanel1Layout.setVerticalGroup(
        jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel1Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(jScrollPane1)
            .addContainerGap())
    );

    jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Member Profile", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.ABOVE_TOP));

    jLabel1.setText("First Name");

    jLabel2.setText("Middle Name");

    jLabel3.setText("Last Name");

    jLabel4.setText("ID");

    idField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

    jLabel5.setText("Birth Date");

    jLabel6.setText("Birth Place");

    jLabel7.setText("Civil Status");

    civilStatusCBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Single", "Married", "Divorced", "Separated", "Widowed " }));

    jLabel8.setText("Home Address");

    jLabel9.setText("Occupation");

    jLabel10.setText("Office");

    jLabel11.setText("Salary");

    jLabel12.setText("Income");

    jLabel13.setText("Relative ");

    jLabel14.setText("Relation");

    jLabel15.setText("Dependents");

    jLabel16.setText("Stock Share");

    jLabel17.setText("Stock Amount");

    jLabel18.setText("Stock Paid");

    jLabel19.setText("Amount Paid");

    btnDelete.setText("Delete");
    btnDelete.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnDeleteActionPerformed(evt);
        }
    });

    btnSaveAndUpdate.setText("Save/Update");
    btnSaveAndUpdate.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnSaveAndUpdateActionPerformed(evt);
        }
    });

    btnAddMember.setText("Add Member");
    btnAddMember.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnAddMemberActionPerformed(evt);
        }
    });

    jLabel20.setText("Gender");

    javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
    jPanel2.setLayout(jPanel2Layout);
    jPanel2Layout.setHorizontalGroup(
        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
            .addGap(30, 30, 30)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(55, 55, 55)
                    .addComponent(btnSaveAndUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(71, 71, 71)
                    .addComponent(btnAddMember, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addGap(18, 18, 18)
                        .addComponent(stockPaidField, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(amountPaidField))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(stockShareField, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(stockAmountField))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(18, 18, 18)
                        .addComponent(officeField, javax.swing.GroupLayout.PREFERRED_SIZE, 437, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(fNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jOptionPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(mNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(lNameField))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sexField, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(homeAddField, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(civilStatusCBox, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(occupationField))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(relativeField, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(relationField, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dependentsField))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(salaryField, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(incomeField, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(106, 106, 106)
                        .addComponent(jLabel2)
                        .addGap(93, 93, 93)
                        .addComponent(jLabel3))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bDayField)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(bPlaceField, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(idField, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))
            .addContainerGap(31, Short.MAX_VALUE))
    );
    jPanel2Layout.setVerticalGroup(
        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel2Layout.createSequentialGroup()
            .addGap(8, 8, 8)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(idField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addComponent(jOptionPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel1)
                .addComponent(jLabel2)
                .addComponent(jLabel3))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(fNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(mNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(lNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel5)
                .addComponent(bDayField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel6)
                .addComponent(bPlaceField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(homeAddField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(sexField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel7)
                .addComponent(civilStatusCBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel9)
                .addComponent(occupationField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel10)
                .addComponent(officeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel11)
                .addComponent(jLabel12)
                .addComponent(salaryField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(incomeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel13)
                .addComponent(relativeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel14)
                .addComponent(relationField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel15)
                .addComponent(dependentsField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel16)
                .addComponent(stockShareField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel17)
                .addComponent(stockAmountField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel18)
                .addComponent(jLabel19)
                .addComponent(amountPaidField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(stockPaidField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(27, 27, 27)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(btnDelete)
                .addComponent(btnSaveAndUpdate)
                .addComponent(btnAddMember))
            .addContainerGap(8, Short.MAX_VALUE))
    );

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );
    layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addContainerGap())
    );

    pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchFieldKeyPressed
        fillTable(searchField.getText());
    }//GEN-LAST:event_searchFieldKeyPressed

    private void searchFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchFieldKeyReleased
        fillTable(searchField.getText());
    }//GEN-LAST:event_searchFieldKeyReleased

    private void memberTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_memberTableMouseClicked

        int selectedRow = memberTable.getSelectedRow();    
        fillDataFields(selectedRow);
                   
    }//GEN-LAST:event_memberTableMouseClicked

    private void btnSaveAndUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveAndUpdateActionPerformed
        
        int selectedRow = memberTable.getSelectedRow();
        int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog(this, "Are you sure you want to Update this Record? ", "Warning", dialogButton);
        if(dialogResult == 0) {
            saveOrUpdateData(selectedRow);
        }
        
        
        
    }//GEN-LAST:event_btnSaveAndUpdateActionPerformed

    private void btnAddMemberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddMemberActionPerformed
               
        int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog(this, "Are you sure you want to Add this Record? ", "Warning", dialogButton);
        if(dialogResult == 0) {
            addRecord();
        }
        
    }//GEN-LAST:event_btnAddMemberActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        
        int selectedRow = memberTable.getSelectedRow();
        int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog(this, "Are you sure you want to Delete this Record? ", "Warning", dialogButton);
        if(dialogResult == 0) {
            deleteRecord(selectedRow);
        }
    
    }//GEN-LAST:event_btnDeleteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField amountPaidField;
    private javax.swing.JTextField bDayField;
    private javax.swing.JTextField bPlaceField;
    private javax.swing.JButton btnAddMember;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnSaveAndUpdate;
    private javax.swing.JComboBox<String> civilStatusCBox;
    private javax.swing.JTextField dependentsField;
    private javax.swing.JTextField fNameField;
    private javax.swing.JTextField homeAddField;
    private javax.swing.JTextField idField;
    private javax.swing.JTextField incomeField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JOptionPane jOptionPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lNameField;
    private javax.swing.JTextField mNameField;
    private javax.swing.JTable memberTable;
    private javax.swing.JTextField occupationField;
    private javax.swing.JComboBox<String> officeField;
    private javax.swing.JTextField relationField;
    private javax.swing.JTextField relativeField;
    private javax.swing.JTextField salaryField;
    private javax.swing.JTextField searchField;
    private javax.swing.JTextField sexField;
    private javax.swing.JTextField stockAmountField;
    private javax.swing.JTextField stockPaidField;
    private javax.swing.JTextField stockShareField;
    // End of variables declaration//GEN-END:variables
}
