/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myPack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Keen
 */
public class UpdateItemForm extends javax.swing.JFrame {

    int oldSID;
    int sID;
    int salesID;
    int totalAmount;
    int quantity;
    ArrayList itemDesc = new ArrayList();
    ArrayList<Integer> itemStockID = new ArrayList<Integer>();
    public boolean itemUpdatedOrDeleted = false;
    
    
    /**
     * Creates new form UpdateItemForm
     */
    public UpdateItemForm(int slID, int stkID) {
        initComponents();
        this.setResizable(false);
        setDefaultCloseOperation(AddItemForm.DISPOSE_ON_CLOSE);
        salesID = slID;
        sID = stkID;
        oldSID = stkID;
        loadItems();
        setFields();
    }
    
     private void loadItems(){
        Connection myCon= myConnect.ConnectDB();
        String qry ="SELECT s4.stockID, s4.description from stock2014 as s4";
         
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            ResultSet rs = myStat.executeQuery();
            
            while(rs.next()){
                itemStockID.add(rs.getInt("s4.stockID"));
                itemDesc.add(rs.getString("s4.description"));
                jComboBoxItem.addItem(rs.getString("s4.description"));
            }            
            
            jComboBoxItem.setSelectedIndex(sID-1);
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }       
    }
     
    private void setFields(){
        Connection myCon= myConnect.ConnectDB();
        String qry = "SELECT si.stockID, si.quantity, si.amount, s.sellingprice from sales_item as si INNER JOIN stock2014 as s ON "
                + "si.stockID = s.stockID WHERE si.salesID = ? AND si.stockID = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setInt(1, salesID);
            myStat.setInt(2, sID);
            
            ResultSet rs = myStat.executeQuery();
            
            while(rs.next()){
            
                quantity = rs.getInt("si.quantity");
                totalAmount = rs.getInt("si.amount");
                jTextFieldQuantity.setText(String.valueOf(quantity));
                jTextFieldAmount.setText(String.valueOf(rs.getInt("s.sellingprice")));
                jLabelTotalAmount.setText(String.valueOf(totalAmount) + ".00");
          
            }            
            
        } catch (Exception e){
            JOptionPane.showMessageDialog (null, "Error: !" + e, "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Error : " + e);
        }
        
    }
    
    private int getItemPrice(){
        
        sID = itemStockID.get(jComboBoxItem.getSelectedIndex());
        
        int itemPrice = 0;
        
        Connection myCon= myConnect.ConnectDB();
        String qry ="SELECT sellingprice from stock2014 WHERE stockID = ?";
         
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setInt(1, sID);
            ResultSet rs = myStat.executeQuery();
            
            while(rs.next()){
                itemPrice  = rs.getInt("sellingprice");
            }            
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }   
        
        return itemPrice;
    }
    
    //------------------------------------------------------------------------------------------
    private void UpdateItem(){
        
        totalAmount = getItemPrice() * quantity;
        
        Connection myCon= myConnect.ConnectDB();
        String qry = "UPDATE sales_item SET stockID = ?, amount = ?, quantity = ? WHERE salesID = ?  AND stockID = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setInt(1, sID);
            myStat.setInt(2, totalAmount);
            myStat.setInt(3, quantity);
            myStat.setInt(4, salesID);
            myStat.setInt(5, oldSID);

            
            myStat.executeUpdate();
            myCon.close();
            
        } catch (Exception e){
            JOptionPane.showMessageDialog (null, "Update Failed!", "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Error : " + e);
        }
    }
    
     private void setExtraFields(){
        quantity = Integer.valueOf(jTextFieldQuantity.getText());
        totalAmount = getItemPrice() * quantity;
        jLabelTotalAmount.setText(totalAmount + ".00");
        jTextFieldAmount.setText(String.valueOf(getItemPrice()));
    }
     
    private void setStockID(){
        
        sID = itemStockID.get(jComboBoxItem.getSelectedIndex());
        
    }
    
    //-----------------------------------------------------------------------------------------
    private void deleteItem(){
        
        Connection myCon= myConnect.ConnectDB();
        String qry = "DELETE FROM sales_item WHERE stockID = ? AND salesID = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            
            myStat.setInt(1, oldSID); 
            myStat.setInt(2, salesID);
            
            myStat.executeUpdate();
            myCon.close();
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBoxItem = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldQuantity = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldAmount = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        jLabelTotalAmount = new javax.swing.JLabel();
        jButtonUpdate = new javax.swing.JButton();
        jButtonDelete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Update Item Form");

        jPanel1.setBackground(java.awt.Color.decode("#dbffff")
        );

        jLabel1.setText("Item:");

        jComboBoxItem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jComboBoxItemMouseExited(evt);
            }
        });

        jLabel2.setText("Quantity:");

        jTextFieldQuantity.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldQuantity.setText("0");
        jTextFieldQuantity.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldQuantityKeyReleased(evt);
            }
        });

        jLabel3.setText("Amount:");

        jTextFieldAmount.setEditable(false);
        jTextFieldAmount.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        jPanel9.setBackground(java.awt.Color.decode("#dbffff"));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Total Amount", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jLabelTotalAmount.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabelTotalAmount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTotalAmount.setText("000.00");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelTotalAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelTotalAmount)
                .addContainerGap())
        );

        jButtonUpdate.setText("Update Item");
        jButtonUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonUpdateActionPerformed(evt);
            }
        });

        jButtonDelete.setText("Delete Item");
        jButtonDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButtonUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBoxItem, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jComboBoxItem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextFieldQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jTextFieldAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonUpdate)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonDelete))
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldQuantityKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldQuantityKeyReleased
        if(jTextFieldQuantity.getText().trim().isEmpty()){
           jTextFieldQuantity.setText("0");
        }
        setExtraFields();
    }//GEN-LAST:event_jTextFieldQuantityKeyReleased

    private void jComboBoxItemMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBoxItemMouseExited
        setStockID();
        setFields();
        setExtraFields();
        jTextFieldAmount.setText(String.valueOf(getItemPrice()));
    }//GEN-LAST:event_jComboBoxItemMouseExited

    private void jButtonUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonUpdateActionPerformed
            
        int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog(this, "Are you sure you want to Update Selected Item?", "Warning", dialogButton);
        if(dialogResult == 0) {
            UpdateItem();
            this.dispose();
            JOptionPane.showMessageDialog(null, "Selected Item Succesfully Updated!", "Succes!", JOptionPane.INFORMATION_MESSAGE);
            itemUpdatedOrDeleted = true;
        }
    }//GEN-LAST:event_jButtonUpdateActionPerformed

    private void jButtonDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDeleteActionPerformed
        
        int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog(this, "Are you sure you want to Delete Selected Item?", "Warning", dialogButton);
        if(dialogResult == 0) {
            deleteItem();
            this.dispose();
            JOptionPane.showMessageDialog(null, "Selected Item Succesfully Deleted!", "Succes!", JOptionPane.INFORMATION_MESSAGE);
            itemUpdatedOrDeleted = true;
        }
        
    }//GEN-LAST:event_jButtonDeleteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateItemForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateItemForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateItemForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateItemForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateItemForm(0,0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonDelete;
    private javax.swing.JButton jButtonUpdate;
    private javax.swing.JComboBox<String> jComboBoxItem;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabelTotalAmount;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JTextField jTextFieldAmount;
    private javax.swing.JTextField jTextFieldQuantity;
    // End of variables declaration//GEN-END:variables
}
