/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myPack;

import java.awt.Dialog;
import java.awt.Dimension;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author Keen
 */
public class POSMainForm extends javax.swing.JFrame {
    
    String cashierName;
    int cashierID;
    ArrayList<Integer> memberID = new ArrayList<Integer>();
    boolean newInvoiceSaved = true;
    public boolean hasAnItem = false;
    int totalSales;
    int totalAmount;
    int gSalesID = -1;
    
    /**
     * Creates new form POSMainForm
     */
    public POSMainForm(String cName, int cID) {
        initComponents();
        
        //Disable resizing frame
        this.setResizable(false);
        
        //Set Date
        setDate();
        
        //Sets Cashier
        cashierName = cName;
        jLabelCashierName.setText(cashierName);
        
        //Sets cashierID
        cashierID = cID;
        
        //Fill Invoice Table
        fillInvoiceTable(jLabelDate.getText(), cashierID);
        
        //Fill jComboBoxCustomer with data 
        getMembersData();
        
        //Set jComboBoxCustomer with null value
        jComboBoxCustomer.setSelectedIndex(-1); 
        
        //Set Button visibility
        jButtonSaveCurrentInvoice.setVisible(false);
    }
    
    private void setDate(){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.now();
        jLabelDate.setText(dtf.format(localDate));
    }
    
    private void fillInvoiceTable(String currDate, int userID) {
        Connection myCon= myConnect.ConnectDB();
        String qry1 = "SELECT i.invoiceNum , m.Lname, m.Fname ,"
               + "i.totalamount, i.Date, i.salesID, i.userid FROM invoice AS i INNER JOIN"
               + " member AS m ON i.memberID = m.memberID WHERE i.Date LIKE ? AND i.userid = ? Order by m.Lname ASC";
        
        String qry2 = "SELECT SUM(totalAmount) from invoice WHERE Date LIKE ? AND userid = ?";
        
        try {
            PreparedStatement myStat1 = myCon.prepareStatement(qry1);
            myStat1.setString(1, currDate);
            myStat1.setString(2, String.valueOf(userID));
            ResultSet rs1 = myStat1.executeQuery();
            
           
            //Set table data
            DefaultTableModel model = (DefaultTableModel) jTableInvoice.getModel();
            model.setRowCount(0);
            
            while(rs1.next())
            { 
                String ORNum = "",customerLName = "", customerFName = "";  
                ORNum = Integer.toString(rs1.getInt("i.invoiceNum"));
                customerLName = rs1.getString("m.Lname");
                customerFName = rs1.getString("m.Fname");
                model.insertRow(jTableInvoice.getRowCount(), new Object[] {ORNum, customerLName, customerFName});
            }
            
            DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
            rightRenderer.setHorizontalAlignment(javax.swing.JLabel.LEADING);
            jTableInvoice.getColumnModel().getColumn(0).setCellRenderer(rightRenderer);
            
            PreparedStatement myStat2 = myCon.prepareStatement(qry2);
            myStat2.setString(1, currDate);
            myStat2.setString(2, String.valueOf(userID));
            ResultSet rs2 = myStat2.executeQuery();
            
            totalSales = 0;
            if(rs2.first()){
                totalSales = rs2.getInt("SUM(totalAmount)");
            }
            
            jLabelTotalSales.setText(String.valueOf(totalSales)+".00"); 
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void fillCurrReceiptTable(int salesID){
        Connection myCon= myConnect.ConnectDB();
        
        String qry = "SELECT si.stockID, s.description, s.sellingprice, si.quantity, si.amount "
                + "from sales_item as si INNER JOIN stock2014 as s ON  si.stockID = s.stockID WHERE salesID = ?";
        
        String qryForTAmount = "SELECT SUM(s.sellingprice*si.quantity) as TAmount from sales_item as si INNER JOIN "
                + "stock2014 as s ON si.stockID = s.stockID WHERE salesID = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setInt(1, salesID);
            ResultSet rs = myStat.executeQuery();
            
            //Set table data
            DefaultTableModel model = (DefaultTableModel) jTableCurrReceipt.getModel();
            model.setRowCount(0);
            
            while(rs.next())
            {
                int stockCode = rs.getInt("si.stockID");
                String description = rs.getString("s.description");
                double sellingPrice = rs.getInt("s.sellingprice");
                int quantity = rs.getInt("si.quantity");
                double amount = rs.getInt("si.amount");
                model.insertRow(jTableCurrReceipt.getRowCount(), new Object[] {stockCode, description, sellingPrice, quantity, amount});
            }
            
            DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
            rightRenderer.setHorizontalAlignment(javax.swing.JLabel.CENTER);
            jTableCurrReceipt.getColumnModel().getColumn(0).setCellRenderer(rightRenderer);
            jTableCurrReceipt.getColumnModel().getColumn(2).setCellRenderer(rightRenderer);
            jTableCurrReceipt.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);
            jTableCurrReceipt.getColumnModel().getColumn(4).setCellRenderer(rightRenderer);
            
            
            //For Amount
            PreparedStatement myStatForTAmount = myCon.prepareStatement(qryForTAmount);
            myStatForTAmount.setInt(1, salesID);
            ResultSet rsForTAmount = myStatForTAmount.executeQuery();
            
            totalAmount = 0;
            if(rsForTAmount.next()){
                totalAmount = rsForTAmount.getInt("TAmount");
            }
            
            jLabelTotalAmount.setText(String.valueOf(totalAmount)+".00");
            
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Error : " + e);
        }
    }
    
    private int getSelectedMember(int memID){
        int mID = -1;
               
        for(int i = 0; i<memberID.size(); i++){
            if(Integer.valueOf(memberID.get(i)) == memID){
                mID = i;
                return mID;
            }
        }
        return mID;
    }
    
    private void fillCurrReceiptDetails(int salesID){
        
        Connection myCon= myConnect.ConnectDB();
        String qry = "SELECT salesID, invoiceNum, memberID, Date FROM invoice WHERE salesID = ?";
         try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setInt(1, salesID);
            ResultSet rs = myStat.executeQuery();
            
            while(rs.next()){
                jTextFieldDateSold.setText(rs.getString("Date"));
                jTextFieldORID.setText(String.valueOf(rs.getInt("salesID")));
                jComboBoxCustomer.setSelectedIndex(getSelectedMember(rs.getInt("memberID")));
                jTextFieldORNumber.setText(rs.getString("invoiceNum"));
            }
            
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
            System.out.println("Error : " + e);
        } 
        
    }
    
    private void getMembersData(){
         Connection myCon= myConnect.ConnectDB();
         String qry =" SELECT `memberID`, `Fname`, `Lname` FROM member "
                + "Order by Lname ASC";
         
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            ResultSet rs = myStat.executeQuery();
            
            while(rs.next()){
                memberID.add(rs.getInt("memberID"));
                String member = rs.getString("Lname") + ", " + rs.getString("Fname");
                jComboBoxCustomer.addItem(member);               
            }            
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }        
    }
    
    private void addNewSale(){
        
        Connection myCon= myConnect.ConnectDB();
        String qry = "INSERT INTO invoice (Date) VALUES (?)";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setString(1, String.valueOf(jTextFieldDateSold.getText()));
            myStat.executeUpdate();
            myCon.close();
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }
    }
    
    private void updateSale(){

        int selectedIndex = jComboBoxCustomer.getSelectedIndex();
        int memID;

        if(selectedIndex == (-1)){
            memID = 9999;    //Set ID as non-member
        }
        else{
            memID = memberID.get(selectedIndex);

        }
       
        Connection myCon= myConnect.ConnectDB();
        String qry = "UPDATE invoice SET `invoiceNum` = ?, `memberID` = ?, `userid` = ? WHERE `salesID` = ?";
        
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            
            myStat.setString(1, jTextFieldORNumber.getText()); 
            myStat.setInt(2, memID);
            myStat.setInt(3, cashierID);
            myStat.setInt(4, Integer.parseInt(getCurrSalesID()));   
            
            myStat.executeUpdate();
            myCon.close();
            newInvoiceSaved = true;
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }
    }
    
    private String getCurrSalesID(){
        
        String SalesID = new String();
        
        Connection myCon= myConnect.ConnectDB(); 
        String qry = "SELECT MAX(salesID) FROM invoice";
        
         try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            ResultSet rs = myStat.executeQuery();
            
            if(rs.first()){
                SalesID = String.valueOf(rs.getInt("MAX(salesID)"));
            }
        } catch (Exception e){
            System.out.println("Error : " + e);
        }

        return SalesID; 
    }
    
    private void clearReceiptFields(){
        jTextFieldDateSold.setText("");
        jTextFieldORID.setText("");
        jComboBoxCustomer.setSelectedIndex(-1);
        jTextFieldORNumber.setText("");
    }
    
    private int getSelectedSalesID(){
        int salesID = -1;
        String SelectedInvoiceNum = String.valueOf(jTableInvoice.getValueAt(jTableInvoice.getSelectedRow(), 0));
        String SelectedCLname = String.valueOf(jTableInvoice.getValueAt(jTableInvoice.getSelectedRow(), 1));
        String SelectedCFname = String.valueOf(jTableInvoice.getValueAt(jTableInvoice.getSelectedRow(), 2));
        
        Connection myCon= myConnect.ConnectDB();
        String qry ="SELECT i.salesID from invoice as i INNER JOIN member as m ON i.memberID = "
                + "m.memberID WHERE invoiceNum LIKE ? AND m.Lname LIKE ? AND m.Fname LIKE ?";
         
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setString(1, SelectedInvoiceNum);
            myStat.setString(2, SelectedCLname);
            myStat.setString(3, SelectedCFname);
            ResultSet rs = myStat.executeQuery();
            
            if(rs.next()){
               salesID = rs.getInt("i.salesID");
            }
            
            return salesID;
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error: " + e, "Error", JOptionPane.ERROR_MESSAGE);
        }   
        
        return salesID;
    }
    
    private void insertTotalAmountForInvoice(){
        
        Connection myCon= myConnect.ConnectDB();        
        String qry = "UPDATE invoice SET totalamount = ? WHERE salesID = ?";
        try {
            PreparedStatement myStat = myCon.prepareStatement(qry);
            myStat.setInt(1, totalAmount);
            myStat.setInt(2, Integer.valueOf(jTextFieldORID.getText()));
            myStat.executeUpdate();
            myCon.close();
            
        } catch (Exception e){
            System.out.println("Error : " + e);
        }
    }
    
    private int getItemStockID(){
        int stockID = 0;
        stockID = Integer.valueOf(String.valueOf(jTableCurrReceipt.getValueAt(jTableCurrReceipt.getSelectedRow(), 0)));
        return stockID;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabelCashierName = new javax.swing.JLabel();
        jButtonLogout = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabelDate = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableInvoice = new javax.swing.JTable();
        jButtonAddNewInvoice = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabelTotalSales = new javax.swing.JLabel();
        jButtonSaveCurrentInvoice = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextFieldDateSold = new javax.swing.JTextField();
        jTextFieldORID = new javax.swing.JTextField();
        jComboBoxCustomer = new javax.swing.JComboBox<>();
        jTextFieldORNumber = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableCurrReceipt = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        jLabelTotalAmount = new javax.swing.JLabel();
        jButtonAddItem = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuManageSystem = new javax.swing.JMenu();
        jMenuCustomer = new javax.swing.JMenu();
        jMenuItemAddCustomer = new javax.swing.JMenuItem();
        jMenuItemUpdateCustomer = new javax.swing.JMenuItem();
        jMenuItemDeleteCustomer = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jMenuItemAddStock = new javax.swing.JMenuItem();
        jMenuItemUpdateStock = new javax.swing.JMenuItem();
        jMenuItemDeleteStock = new javax.swing.JMenuItem();
        jMenuView = new javax.swing.JMenu();
        jMenuItemCustomers = new javax.swing.JMenuItem();
        jMenuItemStocks = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("POS Main Form (JDT)");

        jPanel1.setBackground(java.awt.Color.decode("#dbffff")
        );

        jPanel2.setBackground(java.awt.Color.decode("#dbffff")
        );
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Cashier", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 14))); // NOI18N

        jLabelCashierName.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N

        jButtonLogout.setText("Logout");
        jButtonLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLogoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelCashierName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonLogout)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCashierName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonLogout))
                .addContainerGap())
        );

        jPanel3.setBackground(java.awt.Color.decode("#dbffff")
        );
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED), "Date", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 1, 14))); // NOI18N

        jLabelDate.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabelDate.setText("dd/MM/yyyy");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelDate, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabelDate, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jPanel4.setBackground(java.awt.Color.decode("#dbffff")
        );
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Daily Sale"));

        jTableInvoice.setBackground(java.awt.Color.decode("#eaffff"));
        jTableInvoice.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "OR Number", "Last Name", "First Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableInvoice.getTableHeader().setReorderingAllowed(false);
        jTableInvoice.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTableInvoiceMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTableInvoice);
        if (jTableInvoice.getColumnModel().getColumnCount() > 0) {
            jTableInvoice.getColumnModel().getColumn(0).setResizable(false);
            jTableInvoice.getColumnModel().getColumn(0).setPreferredWidth(100);
            jTableInvoice.getColumnModel().getColumn(1).setResizable(false);
            jTableInvoice.getColumnModel().getColumn(1).setPreferredWidth(175);
            jTableInvoice.getColumnModel().getColumn(2).setResizable(false);
            jTableInvoice.getColumnModel().getColumn(2).setPreferredWidth(175);
        }

        jButtonAddNewInvoice.setText("Add New Invoice");
        jButtonAddNewInvoice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddNewInvoiceActionPerformed(evt);
            }
        });

        jPanel5.setBackground(java.awt.Color.decode("#dbffff"));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Total Sales", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jLabelTotalSales.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabelTotalSales.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTotalSales.setText("0.00");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabelTotalSales, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelTotalSales)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButtonSaveCurrentInvoice.setText("Save Current Invoice");
        jButtonSaveCurrentInvoice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSaveCurrentInvoiceActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButtonAddNewInvoice, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addComponent(jButtonSaveCurrentInvoice, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jButtonAddNewInvoice)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonSaveCurrentInvoice))
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel6.setBackground(java.awt.Color.decode("#dbffff")
        );
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Receipt", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jPanel7.setBackground(java.awt.Color.decode("#dbffff")
        );
        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setText("Date Sold");

        jLabel4.setText("Customer");

        jLabel5.setText("Invoice ID");

        jTextFieldDateSold.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jTextFieldORID.setEditable(false);
        jTextFieldORID.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        jComboBoxCustomer.setEditable(true);

        jTextFieldORNumber.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        jLabel7.setText("Invoice Number");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextFieldDateSold, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldORID, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBoxCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextFieldORNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(16, 16, 16))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5)
                    .addComponent(jTextFieldDateSold, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldORID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBoxCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(jTextFieldORNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jTableCurrReceipt.setBackground(java.awt.Color.decode("#eaffff"));
        jTableCurrReceipt.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Stock Code", "Description", "Selling Price", "Quantity", "Amount"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Double.class, java.lang.Integer.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableCurrReceipt.getTableHeader().setReorderingAllowed(false);
        jTableCurrReceipt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableCurrReceiptMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableCurrReceipt);
        if (jTableCurrReceipt.getColumnModel().getColumnCount() > 0) {
            jTableCurrReceipt.getColumnModel().getColumn(0).setResizable(false);
            jTableCurrReceipt.getColumnModel().getColumn(0).setPreferredWidth(100);
            jTableCurrReceipt.getColumnModel().getColumn(1).setResizable(false);
            jTableCurrReceipt.getColumnModel().getColumn(1).setPreferredWidth(250);
            jTableCurrReceipt.getColumnModel().getColumn(2).setResizable(false);
            jTableCurrReceipt.getColumnModel().getColumn(2).setPreferredWidth(100);
            jTableCurrReceipt.getColumnModel().getColumn(3).setResizable(false);
            jTableCurrReceipt.getColumnModel().getColumn(4).setResizable(false);
        }

        jPanel9.setBackground(java.awt.Color.decode("#dbffff"));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Total Amount", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jLabelTotalAmount.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        jLabelTotalAmount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTotalAmount.setText("0.00");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabelTotalAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelTotalAmount)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        jButtonAddItem.setText("Add New Item");
        jButtonAddItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddItemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jButtonAddItem, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 6, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButtonAddItem)
                        .addGap(25, 25, 25))))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jMenuManageSystem.setBorder(null);
        jMenuManageSystem.setText("Manage System");
        jMenuManageSystem.setToolTipText("");

        jMenuCustomer.setText("Customer");

        jMenuItemAddCustomer.setText("Add Customer");
        jMenuCustomer.add(jMenuItemAddCustomer);

        jMenuItemUpdateCustomer.setText("Update Customer");
        jMenuCustomer.add(jMenuItemUpdateCustomer);

        jMenuItemDeleteCustomer.setText("Delete Customer");
        jMenuCustomer.add(jMenuItemDeleteCustomer);

        jMenuManageSystem.add(jMenuCustomer);

        jMenu1.setText("Stock");

        jMenuItemAddStock.setText("Add Stock");
        jMenu1.add(jMenuItemAddStock);

        jMenuItemUpdateStock.setText("Update Stock");
        jMenu1.add(jMenuItemUpdateStock);

        jMenuItemDeleteStock.setText("Delete Stock");
        jMenu1.add(jMenuItemDeleteStock);

        jMenuManageSystem.add(jMenu1);

        jMenuBar1.add(jMenuManageSystem);

        jMenuView.setText("View");

        jMenuItemCustomers.setText("Customers");
        jMenuView.add(jMenuItemCustomers);

        jMenuItemStocks.setText("Stocks");
        jMenuView.add(jMenuItemStocks);

        jMenuBar1.add(jMenuView);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLogoutActionPerformed
        
        int dialogButton = JOptionPane.YES_NO_OPTION;
        int dialogResult = JOptionPane.showConfirmDialog(this, "Are you sure you want to Logout?", "Warning", dialogButton);
        if(dialogResult == 0) {
            LoginForm LogForm = new LoginForm();
            LogForm.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_jButtonLogoutActionPerformed
    
    private void jButtonAddItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddItemActionPerformed
        if(!jTextFieldORID.getText().trim().isEmpty()){
             AddItemForm AddIForm = new AddItemForm(gSalesID);
        
            //Makes AddItemForm as modal dialog
            JDialog dialog = new JDialog(AddIForm);
            dialog.setTitle(AddIForm.getTitle());
            dialog.setSize(new Dimension(AddIForm.getWidth(), AddIForm.getHeight()));
            dialog.setLocationRelativeTo(AddIForm);
            dialog.add(AddIForm.getContentPane());
            dialog.setModal(true);
            dialog.setVisible(true);

            if(AddIForm.itemAdded){
                hasAnItem = true;
                fillCurrReceiptTable(Integer.valueOf(jTextFieldORID.getText()));
                insertTotalAmountForInvoice();
                fillInvoiceTable(jLabelDate.getText(), cashierID);
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "No Invoice Selected!", "Warning", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jButtonAddItemActionPerformed

    private void jButtonAddNewInvoiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddNewInvoiceActionPerformed
        
        hasAnItem = false;
        
        if(newInvoiceSaved){
            clearReceiptFields();
            getMembersData();
            jTextFieldDateSold.setText(jLabelDate.getText());
            addNewSale();
            jTextFieldORID.setText(getCurrSalesID());
            jButtonSaveCurrentInvoice.setVisible(true);
            jButtonAddItem.setVisible(true);
            newInvoiceSaved = false;
            
            gSalesID = Integer.valueOf(getCurrSalesID());
            
            DefaultTableModel model = (DefaultTableModel) jTableCurrReceipt.getModel();
            model.setRowCount(0);
        }
        else{
           JOptionPane.showMessageDialog(null, "Cannot Add New Invoice, Current Invoice not yet Saved!", "Warning", JOptionPane.WARNING_MESSAGE);
        }
            
    }//GEN-LAST:event_jButtonAddNewInvoiceActionPerformed

    private void jButtonSaveCurrentInvoiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSaveCurrentInvoiceActionPerformed

        if(!jTextFieldORNumber.getText().trim().isEmpty() && hasAnItem){
            jButtonSaveCurrentInvoice.setVisible(false);
            updateSale();
            fillInvoiceTable(jLabelDate.getText(), cashierID);
            JOptionPane.showMessageDialog(null, "Invoice Succesfully Saved!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearReceiptFields();
            
            DefaultTableModel model = (DefaultTableModel) jTableCurrReceipt.getModel();
            model.setRowCount(0);
        }
        else{
            if(jTextFieldORNumber.getText().trim().isEmpty()){
                JOptionPane.showMessageDialog(null, "Cannot Leave Fields Empty!", "Warning", JOptionPane.WARNING_MESSAGE);
            }
            else if (!hasAnItem){
                JOptionPane.showMessageDialog(null, "Customer must buy atleast 1 (one) Item", "Warning", JOptionPane.WARNING_MESSAGE);
            }
        }
    }//GEN-LAST:event_jButtonSaveCurrentInvoiceActionPerformed

    private void jTableInvoiceMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableInvoiceMouseReleased
        if(newInvoiceSaved){
            gSalesID = getSelectedSalesID();
            fillCurrReceiptTable(gSalesID);
            fillCurrReceiptDetails(gSalesID);
            jButtonAddItem.setVisible(true);
        }
        else{
           JOptionPane.showMessageDialog(null, "Current Invoice not yet Saved!", "Warning", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_jTableInvoiceMouseReleased

    private void jTableCurrReceiptMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableCurrReceiptMouseClicked
        if(jTableCurrReceipt.getSelectedRow() >= 0){
            
            UpdateItemForm UIForm = new UpdateItemForm(gSalesID, getItemStockID()); 
             
            //Makes AddItemForm as modal dialog
            JDialog dialog = new JDialog(UIForm);
            dialog.setTitle(UIForm.getTitle());
            dialog.setSize(new Dimension(UIForm.getWidth(), UIForm.getHeight()));
            dialog.setLocationRelativeTo(UIForm);
            dialog.add(UIForm.getContentPane());
            dialog.setModal(true);
            dialog.setVisible(true);
            
            if(UIForm.itemUpdatedOrDeleted){
                fillCurrReceiptTable(Integer.valueOf(jTextFieldORID.getText()));
                insertTotalAmountForInvoice();
                fillInvoiceTable(jLabelDate.getText(), cashierID);
            }
            
        }
    }//GEN-LAST:event_jTableCurrReceiptMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(POSMainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(POSMainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(POSMainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(POSMainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new POSMainForm("Jonel Dominic E. Tapang", 3).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAddItem;
    private javax.swing.JButton jButtonAddNewInvoice;
    private javax.swing.JButton jButtonLogout;
    private javax.swing.JButton jButtonSaveCurrentInvoice;
    private javax.swing.JComboBox<String> jComboBoxCustomer;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabelCashierName;
    private javax.swing.JLabel jLabelDate;
    private javax.swing.JLabel jLabelTotalAmount;
    private javax.swing.JLabel jLabelTotalSales;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuCustomer;
    private javax.swing.JMenuItem jMenuItemAddCustomer;
    private javax.swing.JMenuItem jMenuItemAddStock;
    private javax.swing.JMenuItem jMenuItemCustomers;
    private javax.swing.JMenuItem jMenuItemDeleteCustomer;
    private javax.swing.JMenuItem jMenuItemDeleteStock;
    private javax.swing.JMenuItem jMenuItemStocks;
    private javax.swing.JMenuItem jMenuItemUpdateCustomer;
    private javax.swing.JMenuItem jMenuItemUpdateStock;
    private javax.swing.JMenu jMenuManageSystem;
    private javax.swing.JMenu jMenuView;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableCurrReceipt;
    private javax.swing.JTable jTableInvoice;
    private javax.swing.JTextField jTextFieldDateSold;
    private javax.swing.JTextField jTextFieldORID;
    private javax.swing.JTextField jTextFieldORNumber;
    // End of variables declaration//GEN-END:variables
}
