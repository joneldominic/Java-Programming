/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SolarSystem;

/**
 *
 * @author Keen
 */
public enum Planet {
    
    SUN (1.991E+30, 695950, 0, 0, 24.66, 0, 200),
    MERCURY(3.303E+23, 2433, 57910006.0, 0.38, 58.82, 0,3),
    VENUS(4.869E+24, 6053, 108199995.0, 0.72, 244.59, 40, 8),
    EARTH(5.976E+24, 6371, 149599951.0, 1, 1, 80, 9),
    MARS(6.421E+23, 3380, 227939920.0, 1.52, 1.03, 120, 5),
    JUPITER(1.9E+27, 69758, 778330257.0, 5.2, 0.41, 160, 100),
    SATURN(5.688E+26, 58219, 1429400028.0, 9.5, 0.43, 200, 84),
    URANUS(8.686E+25, 23470, 2870989228.0, 19.2, 0.45, 240, 34),
    NEPTUNE(1.024E+26, 22716, 4504299579.0, 30, 0.66, 280, 33),
    PLUTO(1.08E+24, 5700, 5914000000.0, 39.5, 6.41, 320, 7);
    
    private final double mass;
    private final double radius;
    private final double distanceSun;
    private final double rotateOrbit;
    private final double rotateAxis;
    private float pos;
    private final int hypoDiameter;

    Planet (double mass, double radius, double ditSun, double rotOrbit, double rotAxis, float pos, int hdia){
    
        this.mass = mass;
        this.radius = radius;
        this.distanceSun = ditSun;
        this.rotateOrbit = rotOrbit;
        this.rotateAxis = rotAxis;
        this.pos = pos;
        this.hypoDiameter = hdia;
          
    }
    
    public int gethypoDiameter() {
        
        return this.hypoDiameter; 
        
    }
    
    public float getPos() {
        
        return this.pos;
    }
    
    public double getMass() {
        
        return this.mass;
        
    }
    
    public double getRadius() {
        
        return this.radius;
        
    }
    
    public double getDistanceSun() {
        
        return this.distanceSun;
        
    }
    
    public double getRotateOrbit() {
        
        return this.rotateOrbit;
        
    }
    public double getRotateAxis() {
        
        return this.rotateAxis;
        
    }
}

