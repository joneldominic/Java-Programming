package mySource;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Keen
 */
public class Numero {
    
    private long myNumber;
    
    public Numero(long myNumber){
        this.myNumber = myNumber;
    }
        
    private String numSysConverter(int divisor){
        
        final String DIGITS = "0123456789ABCDEF";
        String result = "";
        long tmpNumber = myNumber;
        
        if(tmpNumber >= 0){
            while(tmpNumber >= divisor){
                int remainder = (int)(tmpNumber % divisor);
                result = DIGITS.charAt(remainder) + result;
                tmpNumber /= divisor;
            }

            result = DIGITS.charAt((int)tmpNumber) + result;
            return result;
        }
        return "Not yet defined";        
    }
    
    //For Roman Numeral Conversion
    //--------------------------------------------------------------------------
    private String repeatProc(char V, int numOfTimes){
        String result = "";
        
        for(int i=0; i<numOfTimes; i++){
            result += V;
        }
        return result;        
    }
    
    private String RomanNumeralConverter(int number){
        
        if(number >= 0){
            
            if (number  < 4){
                return repeatProc('I', number);
            }
            else if (number == 4){
                return "IV";
            }
            else if (number < 9){
                int ctr = number - 5;
                return "V" + repeatProc('I', ctr);
            }
            else if (number == 9){
                return "IX";
            }
            else if (number < 40){
                int tens = number/10;
                int ones = number % 10;
                return repeatProc('X', tens) + RomanNumeralConverter(ones);
            }
            else if (number < 50){
                int ones = number % 10;
                return "XL" + RomanNumeralConverter(ones);
            }
            else if (number < 90){
                int ctr = (number - 50) / 10;
                int ones = number % 10;
                return "L" + repeatProc('X', ctr) + RomanNumeralConverter(ones);
            }
            else if (number < 100){
                int ones = number - 90;
                return "XC" + RomanNumeralConverter(ones);
            }
            else if (number < 400){
                int hundreds = number / 100;
                int tens = number % 100;
                return repeatProc('C', hundreds) + RomanNumeralConverter(tens);
            }
            else if (number < 500){
                int tens = (number - 400);
                return "CD" + RomanNumeralConverter(tens);
            }
            else if (number < 900){
                int hundreds = (number - 500) / 100;
                int tens = number % 100;
                return "D" + repeatProc('C', hundreds) + RomanNumeralConverter(tens);
            }
            else if (number < 1000){
                int tens = number - 900;
                return "CM" + RomanNumeralConverter(tens);
            }
            else if (number < 4000){
                int thousands = number / 1000;
                int hundreds = number % 1000;
                return repeatProc('M', thousands) + RomanNumeralConverter(hundreds);
            }
        }
        return "Not yet defined";
    }
    //--------------------------------------------------------------------------
    
    //Into English Words
    //--------------------------------------------------------------------------
    private String intoEnglish(int number){
        final String[] LESSTWENTY = {"", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"};
        final String[] TENS = {"", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"};
        
        //Maximum value is only upto 2 billion because of int
        if(number >= 0 && number < 2000000000){
            
            if(number == 0){
                return "Zero";
            }
            else if(number < 20){
                return LESSTWENTY[number];
            }
            else if(number < 100){
                int tens = number / 10;
                int ones = number % 10;
                return TENS[tens] + " " + LESSTWENTY[ones];
            }
            else if(number < 1000){
                int hundreds = number / 100;
                int tens = number % 100;
                return LESSTWENTY[hundreds] + " Hundred " + intoEnglish(tens);
            }
            else if(number < 20000){
                int thousand = (number / 1000) % 20;
                int hundreds = number % 1000;
                return LESSTWENTY[thousand] + " Thousand " + intoEnglish(hundreds);
            }
            else if(number < 100000){
                int tenThousand = number / 10000;
                int thousand = number % 10000;
                return TENS[tenThousand] + " " + intoEnglish(thousand);
            }
            else if (number < 1000000){
                int hundredThousand = number / 100000;
                int tenThousand = number % 100000;
                return LESSTWENTY[hundredThousand] + " Hundred " + intoEnglish(tenThousand);
            }
            else if (number < 20000000){
                int million = (number / 1000000) % 20;
                int hundredThousands = number % 1000000;
                return LESSTWENTY[million] + " Million " + intoEnglish(hundredThousands);
            }
            else if (number < 100000000){
                int tenMillion = number / 10000000;
                int million = (number / 1000000) % 10;
                int hundredThousands = number % 1000000;            
                return TENS[tenMillion] + " " + LESSTWENTY[million] + " Million " + intoEnglish(hundredThousands);
            }
            else if (number < 1000000000){
                int hundredMillion = number / 100000000;
                int tenMillion = (number % 100000000) / 10000000;
                int million = (number % 10000000) / 1000000;
                int hundredThousand = number % 1000000;
                return LESSTWENTY[hundredMillion] + " Hundred " + TENS[tenMillion] + " " + LESSTWENTY[million] + " Million " + intoEnglish(hundredThousand);
            }
            else if (number < 2000000000){
                int billion = number / 1000000000;
                int hundredMillion = number % 1000000000;
                return LESSTWENTY[billion] + " Billion " + intoEnglish(hundredMillion);
            }
        }
        return "Not yet defined";  
    }
    //--------------------------------------------------------------------------
    
    //Into Bisaya
    //--------------------------------------------------------------------------
    
    private String intoBisaya(int number){
        final String[] LESSTWENTY = {"", "Usa", "Duha", "Tolo", "Upat", "Lima", "Unom", "Pito", "Walo", "Siyam", "Napulo", "Napulog isa", "Napulog duha", "Napulog Tolo", "Napulog Upat", "Napulog Lima", "Napulog Unom", "Napulog Pito", "Napulog walo", "Napulog siyam"};
        final String[] TENS = {"", "", "Kawhaan", "Katloan", "Kap-atan", "Kalim-an", "Kan-uman", "Kapitoan", "Kawaloan", "Kasiyaman"};
        
        //Maximum value is only upto 2 billion because of int
        if(number >= 0 && number < 2000000000){
            
            if(number == 0){
                return "";
            }
            else if(number < 20){
                return LESSTWENTY[number];
            }
            else if(number < 100){
                int tens = number / 10;
                int ones = number % 10;
                return TENS[tens] + " og " + LESSTWENTY[ones];
            }
            else if(number < 1000){
                int hundreds = number / 100;
                int tens = number % 100;
                return LESSTWENTY[hundreds] + " ka gatos og " + intoBisaya(tens);
            }
            else if(number < 20000){
                int thousand = (number / 1000) % 20;
                int hundreds = number % 1000;
                return LESSTWENTY[thousand] + " ka Libo og " + intoBisaya(hundreds);
            }
            else if(number < 100000){
                int tenThousand = number / 10000;
                int thousand = number % 10000;
                return TENS[tenThousand] + " " + intoBisaya(thousand);
            }
            else if (number < 1000000){
                int hundredThousand = number / 100000;
                int tenThousand = number % 100000;
                return LESSTWENTY[hundredThousand] + " ka gatos " + intoBisaya(tenThousand);
            }
            else if (number < 20000000){
                int million = (number / 1000000) % 20;
                int hundredThousands = number % 1000000;
                return LESSTWENTY[million] + " ka milyon " + intoBisaya(hundredThousands);
            }
            else if (number < 100000000){
                int tenMillion = number / 10000000;
                int million = (number / 1000000) % 10;
                int hundredThousands = number % 1000000;            
                return TENS[tenMillion] + " " + LESSTWENTY[million] + " ka milyon " + intoBisaya(hundredThousands);
            }
            else if (number < 1000000000){
                int hundredMillion = number / 100000000;
                int tenMillion = (number % 100000000) / 10000000;
                int million = (number % 10000000) / 1000000;
                int hundredThousand = number % 1000000;
                return LESSTWENTY[hundredMillion] + " ka gatos " + TENS[tenMillion] + " " + LESSTWENTY[million] + " ka milyon " + intoBisaya(hundredThousand);
            }
            else if (number < 2000000000){
                int billion = number / 1000000000;
                int hundredMillion = number % 1000000000;
                return LESSTWENTY[billion] + " ka bilyon " + intoBisaya(hundredMillion);
            }
        }
        return "Not yet defined";  
    }
    
    //--------------------------------------------------------------------------
    
    public String getBinary(){
        return numSysConverter(2);
      }
    
    public String getOctal(){
        return numSysConverter(8); 
    }
     
    public String getHexadecimal(){
        return numSysConverter(16);
    }
     
    public String getRomanNumeral(){
        return RomanNumeralConverter((int)myNumber);
    }
    
    public String getEnglish(){
        return intoEnglish((int)myNumber);
    }
    
    public String getBisaya(){
        return intoBisaya((int)myNumber);
    }
      
      
}
